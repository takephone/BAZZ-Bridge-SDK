//
//  YGManager.h
//  YagaSDK
//
//  Created by oded regev on 21/05/2018.
//  Copyright © 2018 You Appi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>


@interface YGManager : NSObject <WKScriptMessageHandler>

// The current version of the sdk
extern NSString * _Nonnull const YG_SDK_VERSION;


@property (nonatomic, copy, readonly) NSString * _Nullable appToken;

+ (instancetype _Nonnull ) sharedInstance;

/**
 Initilize Yaga SDK with appToken
 This method will init Yaga
 @param appToken - A unique NSString which identify the integrator when communicating with Yaga servers.
 */
-(void) startWithToken:(NSString * _Nonnull)appToken;

/**
 Report a click event to Yaga server
 This method will do the following:
 1) Send the clickUrlStr and follow redirects
 2) Add Yaga souce to each URL in the chain where needed (according to Yaga conf)
 3) Report on each url in the list
 4) Report to Yaga Server
 @param clickUrlStr - the click url to report for the ad (usually a redirect link to the App Store).
 @param adIdentifier - a unique identifier for the app associated with this ad.
 */
-(void) reportClick:(NSString * _Nonnull)clickUrlStr adIdentifier:(NSString * _Nullable)adIdentifier;

/**
 Report an impression event to Yaga server
 This method will do the following:
 1) Verify that each string in the list is a valid URL
 2) Add Yaga souce to the URL where needed (according to Yaga conf)
 3) Report on each url in the list
 4) Report to Yaga Server
 @param impressionUrlList - an array of (NSString *), contains the list of URL's to report on impression event.
 @param adIdentifier - a unique identifier for the app associated with this ad.
 */
-(void) reportImpression:(NSArray * _Nonnull)impressionUrlList adIdentifier:(NSString * _Nullable)adIdentifier;

/**
 Report device metadata to Yaga server
 This method will do the following:
 1) Collect device metadata (if available)
 2) Report to Yaga Server
 */
-(void) reportDeviceMetadata;

/**
 Report app lifecycle to Yaga server
 */
-(void) reportAppLifecycle;

/**
 Do auth
*/
-(void) auth;

@end
